abstract class AnonymousInnerClass {
	public abstract void display();

	protected abstract void display1();
}
