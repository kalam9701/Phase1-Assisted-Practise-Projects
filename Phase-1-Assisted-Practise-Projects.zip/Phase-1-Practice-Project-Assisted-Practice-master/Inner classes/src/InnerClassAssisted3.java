
public class InnerClassAssisted3 {

	public static void main(String[] args) {
		AnonymousInnerClass i = new AnonymousInnerClass() {

			public void display() {
				System.out.println("Anonymous Inner Class");
			}

			protected void display1() {
				// TODO Auto-generated method stub
				
			}
		};
		i.display();
	}
}




