package com.mphasis;
abstract class AnonymousInnerClass {
	   public abstract void display();
	}
