package constructor;

public class ParamConstrDemO {
	
	public static void main(String[] args) {

		Std std1=new Std(2,"Vish");
		Std std2=new Std(10,"sunny");
		std1.display();
		std2.display();
			}


}
